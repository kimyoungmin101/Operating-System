#include <stdio.h>
#include <pthread.h>
#include <time.h>
#include <stdlib.h>

#define LOOP 10000
#define BUCKETS (101)


typedef struct __node_t{
	int key;
	struct __node_t *next;
} node_t;


typedef struct __list_t{
	node_t *head;
	pthread_mutex_t lock;
} list_t;

void List_Init(list_t *L){
	L->head = NULL;
	pthread_mutex_init(&L->lock, NULL);
}

void List_Insert(list_t *L, int key){
	node_t *new = malloc(sizeof(node_t));
	if(new == NULL){
		perror("malloc");
		return;	
	}
	new->key = key;

	pthread_mutex_lock(&L->lock);
	new->next = L->head;
	L->head = new;
	pthread_mutex_unlock(&L->lock);
}

int List_Lookup(list_t *L, int key){
	int rv = -1;
	pthread_mutex_lock(&L->lock);
	node_t *curr = L->head;
	while(curr){
		if(curr->key == key){
			rv = 0;
			break;
		}
		curr = curr->next;
	}
	pthread_mutex_unlock(&L->lock);
	return rv;
}

typedef struct __hash_t{
	list_t lists[BUCKETS];
} hash_t;

void Hash_Init(hash_t *H){
	int i;
	for(i=0; i<BUCKETS; i++){
		List_Init(&H->lists[i]);
	}
}

void Hash_Insert(hash_t *H, int key){
	List_Insert(&H->lists[key % BUCKETS], key);
}

int Hash_Lookup(hash_t *H, int key){
	return List_Lookup(&H->lists[key % BUCKETS], key);
}

void *mythread(void *arg)
{
	hash_t *h = (hash_t*)arg;
	int i;
	for(i = 0; i < LOOP; i++){
		//insert
		Hash_Insert(h, i);
	}
	return NULL;
}

int main(int argc, char *argv[])
{
	pthread_t T1, T2, T3, T4;
	hash_t HA1;

	Hash_Init(&HA1);

	clock_t start = clock();
	pthread_create(&T1, NULL, mythread, (void*) &HA1);
	pthread_create(&T2, NULL, mythread, (void*) &HA1);
	pthread_create(&T3, NULL, mythread, (void*) &HA1);
	pthread_create(&T4, NULL, mythread, (void*) &HA1);
	mythread(&HA1);

	pthread_join(T1, NULL);
	pthread_join(T2, NULL);
	pthread_join(T3, NULL);
	pthread_join(T4, NULL);
	clock_t end = clock();

	printf("Time : %lf\n", (double)(end-start) / CLOCKS_PER_SEC);

	return 0;
}
