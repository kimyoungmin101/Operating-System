#include <stdio.h>
#include <pthread.h>
#include <time.h>
#include <stdlib.h>

#define LOOP 50000

// 기본 노드 구조
typedef struct __node_t{
	int key;
	struct __node_t *next;
} node_t;

// 기본 리스트 구조
typedef struct __list_t{
	node_t *head;
	pthread_mutex_t lock;
} list_t;

void List_Init(list_t *L){
	L->head = NULL;
	pthread_mutex_init(&L->lock, NULL);
}

void List_Insert(list_t *L, int key){
	//동기화 할 필요없음
	node_t *new = malloc(sizeof(node_t));
	if(new == NULL){
		perror("malloc");
		return;	
	}
	new->key = key;

	// critical section만 락으로 보호
	pthread_mutex_lock(&L->lock);
	new->next = L->head;
	L->head = new;
	pthread_mutex_unlock(&L->lock);
}

int List_Lookup(list_t *L, int key){
	int rv = -1;
	pthread_mutex_lock(&L->lock);
	node_t *curr = L->head;
	while(curr){
		if(curr->key == key){
			rv = 0;
			break;
		}
		curr = curr->next;
	}
	pthread_mutex_unlock(&L->lock);
	return rv; //성공과 실패를 나타냄.
}

void *mythread(void *arg)
{
	//*arg를 다시 counter_t로 캐스팅
	list_t *l = (list_t*)arg;
	int i;
	for(i = 0; i < LOOP; i++){
		//insert
		List_Insert(l, i);
	}
	return NULL;
}

int main(int argc, char *argv[])
{
	pthread_t T1, T2, T3, T4;
	//couter_t 타입 구조체 변수선언
	list_t L1;
	//int result;
	//시간 측정을 위한 변수 선언	
	//time_t start, end;

	//초기화
	List_Init(&L1);

	//&C1을 void* 타입으로 캐스팅해줘야함
	clock_t start = clock();
	pthread_create(&T1, NULL, mythread, (void*) &L1);
	pthread_create(&T2, NULL, mythread, (void*) &L1);
	pthread_create(&T3, NULL, mythread, (void*) &L1);
	pthread_create(&T4, NULL, mythread, (void*) &L1);
	//mythread(&L1);

	pthread_join(T1, NULL);
	pthread_join(T2, NULL);
	//pthread_join(T3, NULL);
	//pthread_join(T4, NULL);
	clock_t end = clock();

	//result = get(&C1);

	//printf("(counter = %d)\n", result);
	printf("시간은 : %lf\n", (double)(end-start) / CLOCKS_PER_SEC);

	return 0;
}
