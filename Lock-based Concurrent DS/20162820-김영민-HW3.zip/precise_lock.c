#include <stdio.h>
#include <pthread.h>
#include <time.h>

#define LOOP 1000000

static volatile int counter = 0;

typedef struct __counter_t{
	int value;
	pthread_mutex_t lock;
} counter_t;

void init(counter_t *c){
	c->value = 0;
	pthread_mutex_init(&c->lock, NULL);
}

void increment(counter_t *c){
	pthread_mutex_lock(&c->lock);
	c->value++;
	pthread_mutex_unlock(&c->lock);
}

void decrement(counter_t *c){
	pthread_mutex_lock(&c->lock);
	c->value++;
	pthread_mutex_unlock(&c->lock);
}

int get(counter_t *c){
	pthread_mutex_lock(&c->lock);
	int rc = c->value;
	pthread_mutex_unlock(&c->lock);

	return rc;
}

void *mythread(void *arg)
{
	counter_t* c = (counter_t*)arg;
	int i;
	for(i = 0; i < LOOP; i++){
		increment(c);
	}
	return NULL;
}

int main(int argc, char *argv[])
{
	pthread_t T1, T2;
	counter_t C1;
	int result;

	init(&C1);

	clock_t start = clock();
	pthread_create(&T1, NULL, mythread, (void*) &C1);
	pthread_create(&T2, NULL, mythread, (void*) &C1);
	pthread_join(T1, NULL);
	pthread_join(T2, NULL);
	clock_t end = clock();

	result = get(&C1);

	printf("(counter = %d)\n", result);
	printf("Time : %lf\n", (double)(end-start) / CLOCKS_PER_SEC);

	return 0;
}
