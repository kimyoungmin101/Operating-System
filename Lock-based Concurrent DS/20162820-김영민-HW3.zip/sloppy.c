#include <stdio.h>
#include <pthread.h>
#include <time.h>

#define LOOP 1000000
#define NUMCPUS 6


typedef struct __counter_t{
	int global;
	pthread_mutex_t glock; 
	int local[NUMCPUS]; 
	pthread_mutex_t llock[NUMCPUS];
	int threshold; 
} counter_t;

void init(counter_t *c, int threshold){
	c->threshold = threshold;

	c->global = 0;
	pthread_mutex_init(&c->glock, NULL);

	int i;
	for(i=0; i<NUMCPUS; i++){
		c->local[i] = 0;
		pthread_mutex_init(&c->llock[i], NULL);
	}
}

void update(counter_t *c, int threadID, int amt){
	pthread_mutex_lock(&c->llock[threadID]);
	c->local[threadID] += amt;
	if(c->local[threadID] >= c->threshold){
		pthread_mutex_lock(&c->glock);
		c->global += c->local[threadID];
		pthread_mutex_unlock(&c->glock);
		c->local[threadID] = 0;
	}
	pthread_mutex_unlock(&c->llock[threadID]);
}
int get(counter_t *c){
	pthread_mutex_lock(&c->glock);
	int val = c->global;
	pthread_mutex_unlock(&c->glock);

	return val; 
}

void *mythread1(void *arg)
{
	counter_t* c = (counter_t*)arg;
	int i;
	
	for(i = 0; i < LOOP; i++){
		update(c, 0, 1);
	}
	return NULL;
}

void *mythread2(void *arg)
{
	counter_t* c = (counter_t*)arg;
	int i;
	
	for(i = 0; i < LOOP; i++){
		update(c, 1, 1);
	}
	return NULL;
}

void *mythread3(void *arg)
{
	counter_t* c = (counter_t*)arg;
	int i;
	
	for(i = 0; i < LOOP; i++){
		update(c, 2, 1);
	}
	return NULL;
}

void *mythread4(void *arg)
{
	counter_t* c = (counter_t*)arg;
	int i;
	
	for(i = 0; i < LOOP; i++){
		update(c, 3, 1);
	}
	return NULL;
}

void *mythread5(void *arg)
{
	counter_t* c = (counter_t*)arg;
	int i;
	
	for(i = 0; i < LOOP; i++){
		update(c, 3, 1);
	}
	return NULL;
}

void *mythread6(void *arg)
{
	counter_t* c = (counter_t*)arg;
	int i;
	
	for(i = 0; i < LOOP; i++){
		update(c, 3, 1);
	}
	return NULL;
}

void *mythread7(void *arg)
{
	counter_t* c = (counter_t*)arg;
	int i;
	
	for(i = 0; i < LOOP; i++){
		update(c, 3, 1);
	}
	return NULL;
}

void *mythread8(void *arg)
{
	counter_t* c = (counter_t*)arg;
	int i;
	
	for(i = 0; i < LOOP; i++){
		update(c, 3, 1);
	}
	return NULL;
}

int main(int argc, char *argv[])
{
	pthread_t T1, T2, T3, T4, T6;
	counter_t C1;
	int result;

	init(&C1, 1024);

	clock_t start = clock();
	pthread_create(&T1, NULL, mythread1, (void*) &C1);
	pthread_create(&T2, NULL, mythread2, (void*) &C1);
	pthread_create(&T3, NULL, mythread3, (void*) &C1);
	pthread_create(&T4, NULL, mythread4, (void*) &C1);
	pthread_create(&T6, NULL, mythread4, (void*) &C1);
	mythread5(&C1);

	pthread_join(T1, NULL);
	pthread_join(T2, NULL);
	pthread_join(T3, NULL);
	pthread_join(T4, NULL);
	pthread_join(T6, NULL);
	clock_t end = clock();

	result = get(&C1);

	printf("(counter = %d)\n", result);
	printf("Time : %lf\n", (double)(end-start) / CLOCKS_PER_SEC);

	return 0;
}
